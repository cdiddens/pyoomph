from pyoomph import *
# Use the predefined NavierStokesEquations
from pyoomph.equations.navier_stokes import *

from pyoomph.output.plotting import MatplotlibPlotter

class Plot2d(MatplotlibPlotter):
    def define_plot(self):
        self.dpi=300
        self.set_view(-0.1,-0.1,1.1,1.2)
        cb_v=self.add_colorbar("velocity","coolwarm",position="top center")
        cb_v.hide_some_ticks=False
        self.add_plot("domain/velocity",colorbar=cb_v)
        self.add_plot("domain/velocity",mode="streamlines")
        for side in ["top","bottom","left","right"]:
            self.add_plot("domain/" + side)

# Create a problem and define it in the run script directly instead of using inheritance
problem=Problem()
# The tangential traction at the top boundary is a parameter that we can adjust. 
T=problem.define_global_parameter(T=0)

# Assemble the equations
eqs=NavierStokesEquations(mass_density=10,dynamic_viscosity=1)
eqs+=MeshFileOutput()
eqs+=NoSlipBC()@["left","right","bottom"]
eqs+=(DirichletBC(velocity_y=0)+NeumannBC(velocity_x=T))@"top"
 # Since we have no inflow/outflow, we need to fix the pressure, since p->p+const is a nullspace transformation. 
eqs+=AverageConstraint(pressure=0)

# To monitor the induced velocity, we define an IntegralObservable for the integral of u^2 over the domain
eqs+=IntegralObservables(U_sqr=dot(var("velocity"), var("velocity")),Area=1,U=lambda U_sqr,Area: square_root(U_sqr)/Area)

# Add mesh and equations
problem+=RectangularQuadMesh(N=25,name="domain")
problem+=eqs@'domain'

problem+=Plot2d(fileext="pdf")
problem.solve()
problem.go_to_param(T=100)
problem.output()
